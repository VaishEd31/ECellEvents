import React from 'react';
import Event from './Event';

const events = [
  {
    title: 'Ideathon',
    location: 'NITK',
    date: '31 Jan 2025',
    description: 'Ideathon is to gather participants to collaboratively identify real-world problems and brainstorm innovative...'
  },
  {
    title: 'ACE The CASE',
    location: 'NITK',
    date: '29 Jan 2025',
    description: 'To provide participants with a platform to analyze and solve real-world case studies related to business,...'
  },
  {
    title: 'E-Pitch',
    location: 'NITK',
    date: '28 Jan 2025',
    description: 'To encourage creative problem-solving and entrepreneurship by challenging participants to come up with viable...'
  }
];

const App = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h1 style={{ textAlign: 'center', fontSize: '2rem', marginBottom: '2rem' }}>Events 📅</h1>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '2rem', justifyContent: 'center' }}>
        {events.map((event, index) => (
          <Event key={index} {...event} />
        ))}
      </div>
    </div>
  );
};

export default App;
