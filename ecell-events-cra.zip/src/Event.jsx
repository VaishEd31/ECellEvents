import React from 'react';
import { FaMapMarkerAlt, FaRegCalendarAlt } from 'react-icons/fa';

const cardStyle = {
  backgroundColor: '#1f2937',
  borderRadius: '1rem',
  padding: '1.5rem',
  maxWidth: '300px',
  boxShadow: '0 0 10px rgba(0,0,0,0.3)',
  color: 'white'
};

const Event = ({ title, location, date, description }) => {
  return (
    <div style={cardStyle}>
      <div style={{ fontSize: '2.5rem', marginBottom: '1rem', color: '#f97316' }}>🔬</div>
      <h2 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '0.5rem' }}>{title}</h2>
      <div style={{ fontSize: '0.875rem', color: '#9ca3af', marginBottom: '0.25rem' }}>
        <FaMapMarkerAlt style={{ marginRight: '0.5rem', display: 'inline' }} /> {location}
      </div>
      <div style={{ fontSize: '0.875rem', color: '#9ca3af', marginBottom: '1rem' }}>
        <FaRegCalendarAlt style={{ marginRight: '0.5rem', display: 'inline' }} /> {date}
      </div>
      <p style={{ fontSize: '0.875rem', color: '#d1d5db', marginBottom: '1rem' }}>{description}</p>
      <button style={{
        backgroundColor: '#f97316',
        padding: '0.5rem 1rem',
        borderRadius: '9999px',
        border: 'none',
        color: 'white',
        fontWeight: '500',
        cursor: 'pointer'
      }}>
        Register ↗
      </button>
    </div>
  );
};

export default Event;
